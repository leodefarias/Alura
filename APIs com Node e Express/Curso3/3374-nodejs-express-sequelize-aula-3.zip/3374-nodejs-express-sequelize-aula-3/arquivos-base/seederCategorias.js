[
  {
    titulo: 'Node.js',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    titulo: 'Java',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    titulo: 'Python',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    titulo: 'C#',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];
